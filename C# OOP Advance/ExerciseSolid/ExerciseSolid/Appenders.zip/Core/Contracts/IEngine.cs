﻿namespace ExerciseSolid.Core.Contracts
{

    public interface IEngine
    {
        void Run();
    }
}
