﻿namespace ExerciseSolid.Layouts.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}
