﻿using _07_InfernoInfinity.Engines.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace _07_InfernoInfinity.Engines
{
    public class Engine : IEngine
    {
        public void Run()
        {
            throw new NotImplementedException();
        }
    }
}
