﻿using System;

namespace ExercisesEncapsulation
{
    class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
