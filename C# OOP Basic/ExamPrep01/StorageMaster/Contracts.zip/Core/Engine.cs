﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Core
{
    public class Engine
    {
        public void Run()
        {

        }
    }
}
