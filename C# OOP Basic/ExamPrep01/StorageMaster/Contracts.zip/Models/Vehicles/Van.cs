﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Models.Vehicles
{
    class Van : Vehicle
    {
        public Van(int capacity) : base(capacity)
        {
        }
    }
}
